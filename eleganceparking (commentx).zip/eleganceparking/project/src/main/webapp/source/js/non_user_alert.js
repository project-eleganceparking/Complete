function non_user() {
	alert("로그인을 먼저해주세요");
}